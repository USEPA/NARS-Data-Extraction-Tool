# sass 0.1.2

* No significant changes other than CRAN compliance.

# sass 0.1.1

* First release.
