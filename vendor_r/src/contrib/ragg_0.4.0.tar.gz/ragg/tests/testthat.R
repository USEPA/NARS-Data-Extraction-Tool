library(testthat)
library(ragg)

test_check("ragg")
