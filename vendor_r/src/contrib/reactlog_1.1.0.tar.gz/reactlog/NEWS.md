reactlog 1.1.0
==========================

- Added a shiny module to inline the current `reactlog`. See `?reactlog_module_ui` for an example (#66)
- Added `reactlog_enable()` and `reactlog_disable()` which replace the need to explicitly set R options (#61)
- Use log entry for status bar instead of a final graph (#67)
- Allow reactlog to handle isolate calls in a non-reactive context (#68)


reactlog 1.0.0
==========================

Initialize package
