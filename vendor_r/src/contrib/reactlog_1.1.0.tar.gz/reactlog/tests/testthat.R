library(testthat)
library(reactlog)

test_check("reactlog")
