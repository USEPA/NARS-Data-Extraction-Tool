library(testthat)
library(styler)

test_check("styler")
