#
#
#
r <- function(y, s, g = 10) {
  b("", "")

  #
  q <- g(d(i), function(i) {
    d(op(t[[p]]), n(i = i))
  })
  f(calls) <- f(g)

  mb <- j(c(
    q(a::b), r,
    y(u = 1)
  ))
  k(b)
}

#
#
