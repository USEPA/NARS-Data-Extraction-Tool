a <- function(x) {
x <- c(1,
       2 + 3,
sin(pi))

if(x > 10) {
    return("done")
                }
        }
