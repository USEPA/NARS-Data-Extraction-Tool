call(
1,
  call2(
    2, 3,
call3(1, 2, 22),
             5
  ),
  144
            )
