a = b = c = d = e = f       = g <- 4
