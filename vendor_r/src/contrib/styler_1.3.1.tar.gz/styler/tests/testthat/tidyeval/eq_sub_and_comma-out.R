a <- function() {
  data_frame(
    b = ,
    c = ,
  )
}
