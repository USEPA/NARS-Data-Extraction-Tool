if (TRUE) c(
  2
) else c(
  1
)

if (TRUE) c(
  2
) else c( # nothing
  1
)

if (TRUE) c(
  2 # also nothing
) else c(
  1
)
