call( # comment
  am
)

call(
  # comment
  am
)

call(
  am # comment
)

call(
  am, # comment
  pm
)


call(b)

call(
  a
)

call(
  a # b
)

call( #
)

call(
  a # b
)
call( # b
  a
)
