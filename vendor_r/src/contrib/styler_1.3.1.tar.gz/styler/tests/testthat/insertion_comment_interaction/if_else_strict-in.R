if(TRUE)NULL else NULL

if(TRUE)NULL else NULL # comment


if(TRUE)NULL else # comment
 NULL

# if(TRUE)NULL # comment
#  else NULL

if(TRUE) # comment
NULL else NULL

if(TRUE # comment
)NULL else NULL

if( # comment
TRUE)NULL else NULL

if # comment
(TRUE)NULL else NULL
