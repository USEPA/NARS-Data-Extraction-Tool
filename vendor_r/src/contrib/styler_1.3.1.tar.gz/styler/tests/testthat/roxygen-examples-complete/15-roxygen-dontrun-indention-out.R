#' Bla
#'
#' @examples
#' \dontrun{
#' xfun::write_utf8("1++1", file)
#' }
#' style_file(
#'   file,
#'    style = tidyverse_style, strict = TRUE
#'    )
#' \dontrun{
#' style_file(
#'   file,
#'    style = tidyverse_style, strict = TRUE
#'    )
#' }
#' if (TRUE)
#'   return(X)
#'
#' if (TRUE)
#' return(X)
#' if (TRUE)
#' return(X)
x <- y
