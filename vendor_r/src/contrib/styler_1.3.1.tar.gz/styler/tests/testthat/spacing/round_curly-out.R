a <- function(x) {
}

if (a) {
  3
}

for (i in 10) {
  i
}

if (x) {
  y
} else if (x) {
  x
} else {
}
