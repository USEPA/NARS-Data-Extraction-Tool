{
  if (TRUE)
    3
else
5
}


{
  if (TRUE) {
    3
    a + b
   }else
    5

   c()
}


{
  if (TRUE)
    3
  else {
    h()
    5 }
}


{
  if (TRUE) {
    3
  }else {
    s()
    5 }
}

if (TRUE)
  1 else
  3

if (FALSE)
  1 + a * ( 31/2) else
  3^k


if (TRUE)
  1+1 else
    3


if (TRUE)
  1 + 1 else a +4
