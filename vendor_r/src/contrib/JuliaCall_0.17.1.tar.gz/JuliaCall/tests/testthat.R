library(testthat)
library(JuliaCall)
test_check("JuliaCall")
