library(testthat)
library(sass)

test_check("sass")
